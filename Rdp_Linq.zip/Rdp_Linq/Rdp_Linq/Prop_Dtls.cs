﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rdp_Linq
{
   public class Prop_Dtls
    {

        public string RawProdId { get; set; }
        public int ProdId{get;set;}
        public string Model_Id{get; set;}
        public int Model_Price{get; set;}
        public string Prod_date{get; set;}
        public string Model_date{ get; set;}
        public string Flag{get; set;}
        public int ModelSalPrice { get; set; }

                                           //  internal static Prop_Dtls ParseLine(string line)
                                           //  {

        //          var columns = line.Split(',');
        //          int price;

        //      return new Prop_Dtls
        //      {
        //          ProdId = Convert.ToInt32(columns[0]),
        //          Model_Id = columns[1],
        //          Prod_date = columns[2],
        //          Model_date = columns[3],
        //          //  Flag = int.TryParse(columns[4], out price),
        //          //   Model_Price = price
        //          Model_Price = int.Parse(columns[4]),
        //      };

        //}

    }
}

﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Xml.Serialization;

namespace Rdp_Linq
{
    class Program
    {
 

        static void Main(string[] args)
        {
            string constr = @"Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=RDP_Framework;Data Source=PC392173\SQLSEVER2008R2";
            string TxtFileWritePath = @"D:\Ankur\Rdp_Linq\Rdp_Linq\Write";
            string TxtXmlWritePath = @"D:\Ankur\Rdp_Linq\Rdp_Linq\Write";
            string FileName = "Ankur_RawFile.txt";
            string XmlFileName = "Ankur_RawFile.xml";
            var Rawdtls = ProcessFile(@"D:\Ankur\Rdp_Linq\Rdp_Linq\Read", "Redtext.txt");
            foreach (var item in Rawdtls)
            {
                Console.WriteLine($"{item.RawProdId, -20}{ item.Model_Id, 10}{ item.Model_Price,10}");
            }
            Console.WriteLine("Hi I am Ankur");
            string msg = "Hi";
             var ValidLst = Validchk(Rawdtls,out msg);

            Console.WriteLine(msg);

            foreach (var item in ValidLst)
            {
                Console.WriteLine($"{item.ProdId,-20}{ item.Model_Id,10}{ item.Model_Price,10} {item.Flag ,10}");
            }

            InsertRawDatabase(constr, Rawdtls);
            InsertIntoTextFilepath(TxtFileWritePath, FileName, ValidLst);

            InsertIntoXmlFilePath(TxtXmlWritePath, XmlFileName, ValidLst);

            Console.ReadLine();
        }

        private static void InsertIntoXmlFilePath(string txtXmlWritePath, string fileName, List<Prop_Dtls> validLst)
        {
            string FileNName = DateTime.Now.ToString("MMddyyyy");
            string FileNewName = fileName.Replace(fileName.Substring(6, 3), FileNName);
            string FileFullPath = Path.Combine(txtXmlWritePath, FileNewName);
            FileStream FS = new FileStream(FileFullPath, FileMode.OpenOrCreate, FileAccess.Write);
            using (StreamWriter SW = new StreamWriter(FS))
            {
                XmlSerializer XS=new XmlSerializer (typeof(List<Prop_Dtls>));
                XS.Serialize(SW, validLst);
            }


        }

        private static void InsertIntoTextFilepath(string path,string fileName, List<Prop_Dtls> rawdtls)
        {
            string FileName = DateTime.Now.ToString("MMddyyyy");
            string NeFileName = fileName.Replace(fileName.Substring(5, 3), FileName);
            string FullFile = Path.Combine(path, NeFileName);
            if (File.Exists(FullFile))
            {
                File.Delete(FullFile);
            }
            FileStream fs = new FileStream(FullFile, FileMode.OpenOrCreate, FileAccess.Write);
            using (StreamWriter SW = new StreamWriter(fs))
            {
                foreach (var item in rawdtls)
                {
                    SW.WriteLine(item.ProdId + "," + item.Model_Id + "," + item.Model_date + "," + item.Prod_date + "," + item.Model_Price + "," + item.Flag);
                }
            }
            if (File.Exists(@"D:\Ankur\Rdp_Linq\Rdp_Linq\Write\Archive\" + NeFileName))
            { File.Delete(@"D:\Ankur\Rdp_Linq\Rdp_Linq\Write\Archive\" + NeFileName); }

            File.Copy(FullFile, @"D:\Ankur\Rdp_Linq\Rdp_Linq\Write\Archive\" + NeFileName);
        }

        private static List<Prop_Dtls> ProcessFile(string path,string filename)
        {
            List<Prop_Dtls> Rawlist = new List<Prop_Dtls>();
            string filepath = Path.Combine(path, filename);
            FileStream fs = new FileStream(filepath, FileMode.Open, FileAccess.Read);
            using (StreamReader sr = new StreamReader(fs))
            {
                
                string Alltext = sr.ReadToEnd();
                string[] TextArray = Alltext.Split('\n');
                for(int i=0;TextArray.Length>i; i++)
                {
                    Prop_Dtls prop_dtls = new Prop_Dtls();
                    string line = TextArray[i];
                    if(line.Length>1)
                    {
                        string[] lineArray = line.Replace("\r".ToString(), "").Split(',');

                        prop_dtls.RawProdId = Convert.ToString(lineArray[0]);
                        prop_dtls.Model_Id = Convert.ToString(lineArray[1]);
                        prop_dtls.Model_date = Convert.ToString(lineArray[2]);
                        prop_dtls.Prod_date = Convert.ToString(lineArray[3]);
                        prop_dtls.Model_Price = Convert.ToInt32(lineArray[4]);
                        Rawlist.Add(prop_dtls);
                    }
                                           
                }

                return Rawlist;
          
           }
        }

        private static List<Prop_Dtls> Validchk(List<Prop_Dtls> rawdtls,out string msg)
        {


            //var chklist = from lst in rawdtls
            //              where lst.Model_Id.StartsWith("ML") && lst.Model_Id.Substring(2, 3).GetType()== typeof(string) 
            //              select lst;

            msg = "";
            List<Prop_Dtls> ValidList = new List<Prop_Dtls>();
          
            foreach (var item in rawdtls )
            {
                Prop_Dtls prpDtls = new Prop_Dtls();
                bool flg = true;
                int Outint;
                DateTime out_Model_date=DateTime.Now, out_Prod_date= DateTime.Now;
                string dataFormat = "MM/dd/yyyy";
            
                // Check ProdId integer
                flg = int.TryParse(item.RawProdId.ToString(), out Outint);
                // Check first to character ML
                if (!item.Model_Id.StartsWith("ML") && flg==true)
                {
                    flg = false;
                }
                // Check from 2nd char to 3 character int
                if(flg == true)
                flg = int.TryParse(item.Model_Id.Substring(2, 3), out Outint);
                if (flg == true)
                    flg = DateTime.TryParseExact(item.Model_date, dataFormat, CultureInfo.InvariantCulture, DateTimeStyles.None,out out_Model_date);
                if (flg == true)
                    flg = DateTime.TryParseExact(item.Prod_date, dataFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out out_Prod_date);
                // Model date  > equal to Prodyas +10 days
                out_Prod_date = out_Prod_date.AddDays(10);
               
                if ( out_Model_date>= out_Prod_date.AddDays(10) && flg==true)
                {
                    flg = false;
                }
                try
                {
                    prpDtls.ProdId = Convert.ToInt32(item.RawProdId);
                    prpDtls.Model_Id = item.Model_Id;
                    prpDtls.Model_date = item.Model_date;
                    prpDtls.Prod_date = item.Prod_date;
                    prpDtls.Model_Price = item.Model_Price;
                    if (flg == true)
                    {
                        prpDtls.Flag = "Valid";
                    }
                    else

                    {
                        prpDtls.Flag = "Not Valid";
                    }
                }
                catch(Exception ex)
                {
                    ex.Message.ToString();
                    msg = ex.Message.ToString();
                }
              
                ValidList.Add(prpDtls);
            }
           
            if (msg == "")
            {
                msg = "Success";
            }
 


            return ValidList;
        }

         public static void InsertRawDatabase(string path, List<Prop_Dtls> rawdtls)
        {
            try
            {
                using (SqlConnection SqlCon = new SqlConnection(path))
                {
                    SqlCon.Open();
                    string Quey = "Insert into dbo.Product_Details (prod_id,model_id,prod_date,model_date) values(@prod_id,@model_id,@prod_date,@model_date)";
                    using (SqlCommand cmd = new SqlCommand(Quey, SqlCon))
                    {
                        foreach (var item in rawdtls)
                        {
                            cmd.Parameters.Clear();
                            cmd.Parameters.AddWithValue("@prod_id", item.ProdId);
                            cmd.Parameters.AddWithValue("@model_id", item.Model_Id);
                            cmd.Parameters.AddWithValue("@prod_date", item.Prod_date);
                            cmd.Parameters.AddWithValue("@model_date", item.Model_date);
                           
                            cmd.ExecuteNonQuery();

                        }
                    }


                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
          
               
        }

        public static List<Prop_Dtls> ProcessXmlFile(string path, string filename)
        {
            string fullpath = Path.Combine(path, filename);
            List<Prop_Dtls> lst = new List<Prop_Dtls>();
            using (FileStream fs = new FileStream(fullpath, FileMode.Open, FileAccess.Read))
            {
                XmlSerializer xmlSr = new XmlSerializer(typeof(List<Prop_Dtls>));
                lst = (List<Prop_Dtls>)xmlSr.Deserialize(fs);
                return lst;
            }
        }

    }
}

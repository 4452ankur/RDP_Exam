﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rdp_Linq
{
  public  class Utility1
    {
        public void ProcessAllmethod()
        {
            string constr = @"Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=RDP_Framework;Data Source=PC392173\SQLSEVER2008R2";
            string TxtFileReadPth = @"D:\Ankur\Rdp_Linq\Rdp_Linq\Read";
            string TxtFileWritePath= @"D:\Ankur\Rdp_Linq\Rdp_Linq\Write";
            string XmlFileReadPth = @"D:\Ankur\Rdp_Linq\Rdp_Linq\Read";
            string XmlFileWritePth = @"D:\Ankur\Rdp_Linq\Rdp_Linq\Write";
        }
    }
}

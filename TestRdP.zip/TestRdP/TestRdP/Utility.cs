﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestRdP;
using System.IO;
using System.Globalization;

namespace TestRdP
{
    public class Utility
    {
        internal static void ProcessAllMethod()
        {
            string InputTxtFldPath = @"C:\Users\Ankur\source\repos\TestRdP\TestRdP";
            string InputTxtFileName = "RawFile.txt";
            string Constr = "";
            List<Property> RawLst = ReadRawFile(InputTxtFldPath, InputTxtFileName);
            List<Property> LstValid = ChkdValidData(RawLst);

        }

 

        private static List<Property> ReadRawFile(string inputTxtFldPath, string inputTxtFilePath)
        {
            List<Property> LstRaw = new List<Property>();
            try
            {
                string FullPath = Path.Combine(inputTxtFldPath, inputTxtFilePath);
                FileStream FS = new FileStream(FullPath, FileMode.Open, FileAccess.Read);
               
                using (StreamReader Sr = new StreamReader(FS))
                {
                    string ReadAllText = Sr.ReadToEnd();
                    string[] ReadAllTextArray = ReadAllText.Split('\n');
                    for (int i = 0; ReadAllTextArray.Length > i; i++)
                    {
                        Property PropDtls = new Property();
                        string Line = ReadAllTextArray[i];
                        if (Line.Length > 1)
                        {
                            string[] LineArray = Line.Replace('\r'.ToString(), "").Split(',');
                            PropDtls.RawProdId = LineArray[0];
                            PropDtls.ModelId = LineArray[1];
                            PropDtls.ModelDate = LineArray[2];
                            PropDtls.ProdDate = LineArray[3];
                            PropDtls.ModelPrice = int.Parse(LineArray[4]);
                            LstRaw.Add(PropDtls);
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            return LstRaw;            
        }

        private static List<Property> ChkdValidData(List<Property> rawLst)
        {
            List<Property> LstValid = new List<Property>();
           
            int Outint;
            bool flg;
            string DateFormat = "MM/dd/yyyy";
            DateTime outModelDate = DateTime.Now;
            DateTime outProdDate = DateTime.Now;

            // ProdId int chk
            foreach (var item in rawLst)
            {
                Property Prop = new Property();
                try
                {
                    // Prod Id Int
                    flg = int.TryParse(item.RawProdId.ToString(), out Outint);
                    //Model ID first 2 char ML
                    if (flg = item.ModelId.StartsWith("ML") && flg == true)
                    {
                        flg = true;
                    }
                    //Last 3 char int
                    if(flg==true)
                    {
                        flg = int.TryParse(item.ModelId.Substring(2, 3).ToString(),out Outint);
                    }
                    // Model date format MM/dd/yyyy
                    if (flg == true)
                    {
                        flg = DateTime.TryParseExact(item.ModelDate.ToString(), DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out outModelDate);
                    }
                    // Prod date format MM/dd/yyyy
                    if (flg == true)
                    {
                        flg = DateTime.TryParseExact(item.ProdDate.ToString(), DateFormat, System.Globalization.CultureInfo.InvariantCulture, DateTimeStyles.None, out outProdDate);
                    }
                    // Prod date > Model date
                    if(flg==true)
                    {
                        if(outModelDate>outProdDate.AddDays(10) )
                        {
                            flg = false;
                        }
                    }
                    // ModelPrice int
                    if (flg == true)
                    {
                        flg = int.TryParse(item.ModelPrice.ToString(), out Outint);
                    }
                    // Add Vald and Invalid Flafg and list
                    Prop.ProdId = Convert.ToInt32(item.RawProdId);
                    Prop.ModelId = Convert.ToString(item.ModelId);
                    Prop.ModelDate= Convert.ToString(item.ModelDate);
                    Prop.ProdDate = Convert.ToString(item.ProdDate);
                    Prop.ModelPrice = Convert.ToInt32(item.ModelPrice);

                    if(flg==true)
                    {
                        Prop.Flag = "Valid";
                    }
                    else
                    {
                        Prop.Flag = "In Valid";
                    }
                    LstValid.Add(Prop);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                
            }
            return LstValid;
        }
    }
}

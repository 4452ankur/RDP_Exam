﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestRdP
{
   public class Property
    {
        public string  RawProdId { get; set; }
        public int ProdId { get; set; }
        public string ModelId { get; set; }
        public int ModelPrice { get; set; }
        public string ProdDate { get; set; }
        public string ModelDate { get; set; }
        public string Flag { get; set; }
        public int ModelSalePrice { get; set; }
    }
}
